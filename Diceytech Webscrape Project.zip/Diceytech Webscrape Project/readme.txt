Hi, attached in this file are:

Raw_Data:
1. Onthemarket: This contains the scraped files(onthemarket_buy.ipynb and onthemarket_sale.ipynb) and the saved scraped dataset(onthemarket_buy.csv and onthemarket_sale.csv).
2. RightMove: This contains the scraped files(right_move_buy.ipynb and right_move_sale.ipynb) and the saved scraped dataset(right_move_buy.csv and right_move_sale.csv).
3. Zoopla: This contains the scraped files(zoopla_buy.ipynb and zoopla_buy_sale.ipynb) and the saved scraped dataset(zoopla_buy_buy.csv and zoopla_buy_sale.csv).
4. data_preprocessing.ipynb: This is the code for preprocessing the scarped data.

Transformed_Data:
1. listing.csv: This dataset is the combination of both merged preprocessed scraped data (rent listing + sale listing).
2. rent_listing: This dataset is the preprocessed data for all rent listing.
3. sale_listing: This dataset is the preprocessed data for all sale listing.